# Commented out IPython magic to ensure Python compatibility.
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
# %matplotlib inline
import warnings
warnings.filterwarnings('ignore')
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import classification_report, confusion_matrix

df=pd.read_csv("data.csv")
df.head()

df.shape

df.dtypes

df.columns

corrmat = df.corr()
fig = plt.figure(figsize = (45, 10))
sns.heatmap(corrmat, vmax = 0.8, square = True,annot=True)

cor_target = abs(corrmat["status"])
#Selecting highly correlated features
relevant_features = cor_target[cor_target>0.2]
relevant_features

new_df = df[relevant_features.index]

l=["MDVP:Fo(Hz)","MDVP:Flo(Hz)","HNR","spread1","D2"]
m=new_df[l]
print(m)

scaler=MinMaxScaler((-1,1))
m=scaler.fit_transform(m)
#print(m)

d={}
values=[[] for i in range(5)]
for i in range(len(m)):
  for j in range(5):
    values[j].append(m[i][j])
for i in range(5):
  d[l[i]]=values[i]

df_trans=pd.DataFrame(d)
print(df_trans)

new_df['MDVP:Fo(Hz)']=values[0]
new_df['MDVP:Flo(Hz)']=values[1]
new_df['HNR']=values[2]
new_df['spread1']=values[3]
new_df['D2']=values[4]
print(new_df)

x=new_df.drop(['status'],axis=1)
y=new_df['status']
print(x.shape)

x_train,x_test,y_train,y_test=train_test_split(x, y, test_size=0.2, random_state=7)

gbc = GradientBoostingClassifier()
gbc.fit(x_train,y_train)
y_pred=gbc.predict(x_test)
print(classification_report(y_test,y_pred))
accuracy1=gbc.score(x_test,y_test)
print (accuracy1*100,'%')
cm = confusion_matrix(y_test, y_pred)
print(cm)
y_pred=y_pred.tolist()
y_test=y_test.tolist()
print("ACTUAL\tPREDICTED")
for i in range(len(y_test)):
  print(str(y_test[i])+"\t"+str(y_pred[i]))

des_class=DecisionTreeClassifier()
des_class.fit(x_train,y_train)
des_predict=des_class.predict(x_test)
print(classification_report(y_test,des_predict))
accuracy3=des_class.score(x_test,y_test)
print(accuracy3*100,'%')
cm = confusion_matrix(y_test, des_predict)
print(cm)

nvclassifier = GaussianNB ()
nvclassifier .fit(x_train,y_train)
y_pred=nvclassifier.predict(x_test)
print(classification_report(y_test,y_pred))
print(accuracy_score(y_pred,y_test)*100,'%')
cm = confusion_matrix(y_test, y_pred)
print(cm)

inp=[[119.992,74.997,0.00784,0.00007,0.0037,0.00554,0.01109,0.04374,0.426,0.02182,0.0313,0.02971,0.06545,21.033,0.414783,0.815285,-4.813031,0.266482,2.301442,0.284654]]
inp1=[[201.464,195.708,0.00198,0.00001,0.00105,0.00115,0.00314,0.01194,0.107,0.00586,0.0076,0.00957,0.01758,31.732,0.344252,0.742737,-7.777685,0.170183,2.447064,0.05761]]
output=gbc.predict(scaler.fit_transform(inp1))
if output==1:
  print("Parkinsons Disease predicted")
else:
  print("Healthy")

import pickle

pickle.dump(gbc, open('model_gbc.pkl','wb'))
model_gbc = pickle.load(open('model_gbc.pkl','rb'))